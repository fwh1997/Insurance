package util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class C3P0Util {
private static ComboPooledDataSource dataSource = new ComboPooledDataSource();
	
	/**
	 * ʹ�����ӳط���һ�����Ӷ���
	 * @return
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}
	/**
	 * �������ӳض���
	 * @return
	 */
	public static DataSource getDataSource() {
		return dataSource;
	}
}
