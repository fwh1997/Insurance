package dao;

import daomain.Zinfo;

public interface ZinfoDao {
	int addZinfo(Zinfo zinfo);
}
