package dao;

import daomain.Breply;

public interface BreplyDao {
	int addBreply(Breply breply);
}
