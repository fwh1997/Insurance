package dao;

import daomain.Claim;

public interface ClaimDao {
	int addClaim(Claim claim);
}
