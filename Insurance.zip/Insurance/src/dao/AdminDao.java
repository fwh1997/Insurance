package dao;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;

import daomain.Admin;
import daomain.AdminStatus;
import util.C3P0Util;

public interface AdminDao {
	QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
	int addAdmin(Admin admin); // ���ӹ���Ա
	int deleteAdmin(String aName); // ɾ������Ա
	int updateAdmin(String oldName,Admin admin); // ������Ϣ
	Admin getAppointAdmin(String aName);
	List<Admin> getAllAdmins();
	List<Admin> findByStatus(AdminStatus as);
}
