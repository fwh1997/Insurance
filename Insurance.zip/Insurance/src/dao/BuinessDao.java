package dao;

import daomain.Business;

public interface BuinessDao {
	int CreateBuiness(Business business);
}
