package dao.impl;

import java.sql.SQLException;
import java.util.List;

import dao.AdminDao;
import daomain.Admin;
import daomain.AdminStatus;

public class AdminDaoimpl implements AdminDao{

	@Override
	public int addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		if(getAppointAdmin(admin.getaName()) == null) {
			String sql = "insert into admin(aName,aPwd,aPermission)values(?,?,?)";
			Object[] param = new Object[] {admin.getaName(),admin.getaPwd(),admin.getaPermission()};
			try {
				qr.update(sql, param);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return 1;
		}
		return 0;
	}

	@Override
	public int deleteAdmin(String aName) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateAdmin(String oldName, Admin admin) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Admin getAppointAdmin(String aName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> getAllAdmins() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> findByStatus(AdminStatus as) {
		// TODO Auto-generated method stub
		return null;
	}

}
