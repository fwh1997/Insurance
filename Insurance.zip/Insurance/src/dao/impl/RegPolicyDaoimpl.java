package dao.impl;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;

import dao.RegPolicyDao;
import daomain.RegPolicy;
import util.C3P0Util;

public class RegPolicyDaoimpl implements RegPolicyDao{
QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
	@Override
	public int addRegPolicy(RegPolicy regPolicy) {
		String insertsql="insert into regpolicy(rDateReg,rTerm,rStatus,zName,zNumber,iName,iNumber,pName,pMoney,pMinLose,pMaxLose) value(?,?,?,?,?,?,?,?,?,?,?)";
		Object[] insertps= {regPolicy.getRdatereg(),regPolicy.getRterm(),regPolicy.getRstatus(),regPolicy.getZname(),regPolicy.getZnumber(),regPolicy.getIname(),regPolicy.getInumber(),regPolicy.getPname(),regPolicy.getPmoney(),regPolicy.getPminlose(),regPolicy.getPmaxlose()};
		try {
			qr.update(insertsql, insertps);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
		
	}
	@Override
	public int changeStatus(RegPolicy regPolicy) {
		// TODO Auto-generated method stub
		String updatesql="update regpolicy set rStatus=? where zName=? and iName=?";
		Object[] updateps= {regPolicy.getRstatus(),regPolicy.getZname(),regPolicy.getIname()};
		try {
			qr.update(updatesql, updateps);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

}
