package dao.impl;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import dao.ClaimDao;
import daomain.Claim;
import util.C3P0Util;

public class ClaimDaoImpl implements ClaimDao{
QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
	@Override
	public int addClaim(Claim claim) {
		// TODO Auto-generated method stub
		String insertsql="insert into claim(cDesc,cFile,pName) value(?,?,?)";
		Object[] inseryps= {claim.getcDesc(),claim.getcFile(),claim.getpName()};
		try {
			qr.update(insertsql,inseryps);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

}
