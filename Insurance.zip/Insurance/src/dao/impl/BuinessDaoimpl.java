package dao.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.dbutils.QueryRunner;

import dao.BuinessDao;
import daomain.Business;
import util.C3P0Util;

public class BuinessDaoimpl implements BuinessDao{
QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
	@Override
	public int CreateBuiness(Business business) {
		// TODO Auto-generated method stub
		String insetrsql="insert into buiness(bId,bPaymentTime,bMoney,bDescription,rId) value(?,?,?,?,?)";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		int rid = 0;
		return rid;
		
	}

}
