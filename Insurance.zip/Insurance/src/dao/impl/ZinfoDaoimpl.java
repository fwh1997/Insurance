package dao.impl;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import dao.ZinfoDao;
import daomain.Zinfo;
import util.C3P0Util;

public class ZinfoDaoimpl implements ZinfoDao{
QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
	@Override
	public int addZinfo(Zinfo zinfo) {
		// TODO Auto-generated method stub
		String insertsql="insert into zinfo(zName,zNumber,zTel,zBirthday,zAddress,iName,iNumber,iTel,iAddress) value(?,?,?,?,?,?,?,?,?)";
		Object[] insertps= {zinfo.getZname(),zinfo.getZnumber(),zinfo.getZtel(),zinfo.getZbirthday(),zinfo.getZaddress(),zinfo.getIname(),zinfo.getInumber(),zinfo.getItel(),zinfo.getIaddress()};
		try {
			qr.update(insertsql,insertps);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

}
