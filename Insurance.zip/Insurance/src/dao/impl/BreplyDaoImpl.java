package dao.impl;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import dao.BreplyDao;
import daomain.Breply;
import util.C3P0Util;

public class BreplyDaoImpl implements BreplyDao{
QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
@Override
	public int addBreply(Breply breply) {
		// TODO Auto-generated method stub
		String insertsql="insert into breply(bDesc,cPayMoney,pName,aId) value(?,?,?,?)";
		Object[] insertps= {breply.getbDesc(),breply.getcPayMoney(),breply.getpName(),breply.getaId()};
		try {
			qr.update(insertsql,insertps);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
}
