package dao.impl;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.junit.Test;

import dao.PolicyDao;
import daomain.Policy;
import util.C3P0Util;

public class PolicyDaoimpl implements PolicyDao{
	QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
	@Override
	public int addPolicy(Policy policy) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deletePolicy(Policy policy) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updatePolicy(Policy policy) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Test
	public void Test() {
		try {
			System.out.println(C3P0Util.getConnection());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
