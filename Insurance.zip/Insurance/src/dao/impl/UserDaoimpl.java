package dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.Cookie;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.junit.Test;

import com.sun.org.apache.bcel.internal.generic.NEW;

import dao.UserDao;
import daomain.User;
import util.C3P0Util;
import util.DBUtil;

public class UserDaoimpl implements UserDao{
	QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
	PreparedStatement ps;
	ResultSet rs;
	Connection con;
	Connection connection=DBUtil.getConnection();
	
	@Override
	@Test
	public int saveUser(User user){
		// TODO Auto-generated method stub
		int result=0;
		String insertsql="insert into userinfo(uId,uName,uPwd,uEmail) value(?,?,?,?)";
		/*ps=connection.prepareStatement(insertsql);*/
/*		ps.setInt(1, user.getuId());
		ps.setString(2, user.getuName());
		ps.setString(3, user.getuPwd());
		ps.setString(4, user.getuEmail());*/
		/*ps.setInt(1, 5);
		ps.setString(2, "������");
		ps.setString(3, "123");
		ps.setString(4, "21312@qq.com");*/
		System.out.println(user.getuName());
		System.out.println(user.getuPwd());
		System.out.println(user.getuEmail());
		Object[] insertps= {user.getuId(),user.getuName(),user.getuPwd(),user.getuEmail()};
		try {
			qr.update(insertsql, insertps);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("�½��û��ɹ�");
		return result;
	}

	@Override
	public int loginUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		
		int result=0;
		String selectsql="select uPwd from userinfo where uName=? and uPwd=?";
		Object[] selectps= {user.getuName(),user.getuPwd()};
		System.out.println(user.getuName());
		Map map=qr.query(selectsql, new MapHandler(),selectps);
		int status = 0;
		if (map==null) {
			status=0;
		}else if(map!=null){status=1;}
		return status;
	}
	@Override
	public int deleteUser(int uId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateUser(User user) {
		// TODO Auto-generated method stub
		return 0;
	}

}
