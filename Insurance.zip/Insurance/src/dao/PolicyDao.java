package dao;

import daomain.Policy;

public interface PolicyDao {
	int addPolicy(Policy policy);
	int deletePolicy(Policy policy);
	int updatePolicy(Policy policy);
}
