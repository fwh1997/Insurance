package dao;

import daomain.RegPolicy;

public interface RegPolicyDao {
	int addRegPolicy(RegPolicy regPolicy);
	int changeStatus(RegPolicy regPolicy);
}
