package TestServlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;
import dao.impl.UserDaoimpl;
import daomain.User;

public class TestLoginServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		String name=req.getParameter("uName");
		String pwd=req.getParameter("uPwd");
		HttpSession session=req.getSession();
		UserDao userDao=new UserDaoimpl();
		User user=new User();
		user.setuName(name);
		user.setuPwd(pwd);
		try {
			if (userDao.loginUser(user)==1) {
				System.out.println("��½�ɹ�");
				session.setAttribute("uname", name);
				resp.sendRedirect("User/policylist.jsp");
			}else {System.out.println("��¼ʧ��");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			userDao.loginUser(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(req, resp);
	}
}
