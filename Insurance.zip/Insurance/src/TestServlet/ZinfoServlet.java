package TestServlet;

import java.io.IOException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;

import dao.ZinfoDao;
import dao.impl.ZinfoDaoimpl;
import daomain.Zinfo;
@WebServlet("/ZinfoServlet")
public class ZinfoServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.setCharacterEncoding("UTF-8");
	ZinfoDao zinfoDao=new ZinfoDaoimpl();
	Zinfo zinfo=new Zinfo();
	String zname=req.getParameter("zName");
	String znumber=req.getParameter("zNumber");
	String zbirthday=req.getParameter("zBirthday");
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-hh");
	String ztel=req.getParameter("zTel");
	String zaddress=req.getParameter("zAddress");
	String iname=req.getParameter("iName");
	String inumber=req.getParameter("iNumber");
	String itel=req.getParameter("iTel");
	String iaddress=req.getParameter("iAddress");
	zinfo.setZname(zname);
	zinfo.setZnumber(znumber);
	try {
		zinfo.setZbirthday(sdf.parse(zbirthday));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	zinfo.setZtel(ztel);
	zinfo.setZaddress(zaddress);
	zinfo.setIname(iname);
	zinfo.setInumber(inumber);
	zinfo.setItel(itel);
	zinfo.setIaddress(iaddress);
	zinfoDao.addZinfo(zinfo);
}
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	this.doGet(req, resp);
}
}
