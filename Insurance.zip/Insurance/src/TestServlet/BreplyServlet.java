package TestServlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;

import dao.BreplyDao;
import dao.impl.BreplyDaoImpl;
import daomain.Breply;
import util.C3P0Util;
@WebServlet("/BreplyServlet")
public class BreplyServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		req.setCharacterEncoding("UTF-8");
		BreplyDao breplyDao=new BreplyDaoImpl();
		Breply breply=new Breply();
		String bdesc=req.getParameter("bDesc");
		String cpaymoney=req.getParameter("cPayMoney");
		int icpaymoney=Integer.valueOf(cpaymoney);;
		String pname=req.getParameter("pName");
		String aid=req.getParameter("aId");
		int iaid=Integer.valueOf(aid);
		breply.setbDesc(bdesc);
		breply.setcPayMoney(icpaymoney);
		breply.setpName(pname);
		breply.setaId(iaid);
		breplyDao.addBreply(breply);
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(req, resp);
	}
}
