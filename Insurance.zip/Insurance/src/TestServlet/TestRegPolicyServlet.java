package TestServlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;

import com.sun.org.apache.bcel.internal.generic.NEW;

import dao.RegPolicyDao;
import dao.impl.RegPolicyDaoimpl;
import daomain.RegPolicy;

public class TestRegPolicyServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Test
	public void testadd() {
		RegPolicyDao regPolicyDao=new RegPolicyDaoimpl();
		RegPolicy regPolicy=new RegPolicy();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date time=null;
		try {
			time=sdf.parse(sdf.format(new Date()));//תΪʱ�����
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		regPolicy.setRdatereg(time);
		regPolicy.setRterm(1);
		regPolicy.setRstatus(0);
		regPolicy.setZname("С��ͬѧ������");
		regPolicy.setZnumber("360602188805052122");
		regPolicy.setIname("С��ͬѧ");
		regPolicy.setInumber("360602199710308752");
		regPolicy.setPname("ƽ�����ٰ�������");
		regPolicy.setPmoney(1000);
		regPolicy.setPminlose(10000);
		regPolicy.setPmaxlose(100000);
		regPolicyDao.addRegPolicy(regPolicy);
	}
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	super.doGet(req, resp);
}
}
