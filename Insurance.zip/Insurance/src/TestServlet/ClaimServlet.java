package TestServlet;

import javax.servlet.http.HttpServlet;

import org.junit.Test;

import dao.ClaimDao;
import dao.impl.ClaimDaoImpl;
import daomain.Claim;

public class ClaimServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Test
	public void test() {
		ClaimDao claimDao=new ClaimDaoImpl();
		Claim claim=new Claim();
		claim.setcDesc("�������������");
		claim.setcFile("XXX.JPG");
		claim.setpName("ƽ�����ٰ�������");
		claimDao.addClaim(claim);
	}
}
