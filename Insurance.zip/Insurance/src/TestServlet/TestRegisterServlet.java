package TestServlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;
import dao.impl.UserDaoimpl;
import daomain.User;

public class TestRegisterServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		UserDao userDao=new UserDaoimpl();
		User user=new User();
		String uname=req.getParameter("uName");
        String upwd=req.getParameter("uPwd");
        String uemail=req.getParameter("uEmail");
        user.setuName(uname);
        user.setuPwd(upwd);
        user.setuEmail(uemail);
		userDao.saveUser(user);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(req, resp);
	}
}
