package daomain;

import java.util.Date;

public class Business {
	private int bId;
	private Date bPaymentTime;
	private int bMoney;
	private String bDescription;
	private int rId;
	public int getbId() {
		return bId;
	}
	public void setbId(int bId) {
		this.bId = bId;
	}
	public Date getbPaymentTime() {
		return bPaymentTime;
	}
	public void setbPaymentTime(Date bPaymentTime) {
		this.bPaymentTime = bPaymentTime;
	}
	public int getbMoney() {
		return bMoney;
	}
	public void setbMoney(int bMoney) {
		this.bMoney = bMoney;
	}
	public String getbDescription() {
		return bDescription;
	}
	public void setbDescription(String bDescription) {
		this.bDescription = bDescription;
	}
	public int getrId() {
		return rId;
	}
	public void setrId(int rId) {
		this.rId = rId;
	}
	public Business(int bId, Date bPaymentTime, int bMoney, String bDescription, int rId) {
		super();
		this.bId = bId;
		this.bPaymentTime = bPaymentTime;
		this.bMoney = bMoney;
		this.bDescription = bDescription;
		this.rId = rId;
	}
	
}
