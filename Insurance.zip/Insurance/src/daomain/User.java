package daomain;

public class User {
	private int uId;
	private String uName;
	private String uPwd;
	private String uEmail;
	public int getuId() {
		return uId;
	}
	public void setuId(int uId) {
		this.uId = uId;
	}
	public String getuPwd() {
		return uPwd;
	}
	public void setuPwd(String uPwd) {
		this.uPwd = uPwd;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuEmail() {
		return uEmail;
	}
	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}
	public User() {}
	public User(int uId,String uName,String uPwd,String uEmail) {
		this.uId=uId;
		this.uName=uName;
		this.uPwd=uPwd;
		this.uEmail=uEmail;
	}
	public User(String uName,String uPwd,String uEmail) {
		this.uName=uName;
		this.uPwd=uPwd;
		this.uEmail=uEmail;
	}
}
