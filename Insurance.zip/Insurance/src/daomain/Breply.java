package daomain;

public class Breply {
	private String bDesc;
	private int cPayMoney;
	private String pName;
	private int aId;
	public String getbDesc() {
		return bDesc;
	}
	public void setbDesc(String bDesc) {
		this.bDesc = bDesc;
	}
	public int getcPayMoney() {
		return cPayMoney;
	}
	public void setcPayMoney(int cPayMoney) {
		this.cPayMoney = cPayMoney;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getaId() {
		return aId;
	}
	public void setaId(int aId) {
		this.aId = aId;
	}
	public Breply() {
		// TODO Auto-generated constructor stub
	}
	public Breply(String bDesc, int cPayMoney, String pName, int aId) {
		super();
		this.bDesc = bDesc;
		this.cPayMoney = cPayMoney;
		this.pName = pName;
		this.aId = aId;
	}
	
}
