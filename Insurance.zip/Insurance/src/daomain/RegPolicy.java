package daomain;

import java.util.Date;

public class RegPolicy {
	private int rid;
	private Date rdatereg;
	private int rterm;
	private int rstatus;
	private String zname;
	private String znumber;
	private String iname;
	private String inumber;
	private String pname;
	private int pmoney;
	private int pminlose;
	private int pmaxlose;
	public Date getRdatereg() {
		return rdatereg;
	}
	public void setRdatereg(Date rdatereg) {
		this.rdatereg = rdatereg;
	}
	public int getRterm() {
		return rterm;
	}
	public void setRterm(int rterm) {
		this.rterm = rterm;
	}
	
	public int getRstatus() {
		return rstatus;
	}
	public void setRstatus(int rstatus) {
		this.rstatus = rstatus;
	}
	public String getZname() {
		return zname;
	}
	public void setZname(String zname) {
		this.zname = zname;
	}
	public String getZnumber() {
		return znumber;
	}
	public void setZnumber(String znumber) {
		this.znumber = znumber;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getInumber() {
		return inumber;
	}
	public void setInumber(String inumber) {
		this.inumber = inumber;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPmoney() {
		return pmoney;
	}
	public void setPmoney(int pmoney) {
		this.pmoney = pmoney;
	}
	public int getPminlose() {
		return pminlose;
	}
	public void setPminlose(int pminlose) {
		this.pminlose = pminlose;
	}
	public int getPmaxlose() {
		return pmaxlose;
	}
	public void setPmaxlose(int pmaxlose) {
		this.pmaxlose = pmaxlose;
	}
	public RegPolicy() {}
	public RegPolicy( Date rdatereg, int rterm, int rstatus, String zname, String znumber, String iname,
			String inumber, String pname, int pmoney, int pminlose, int pmaxlose) {
		super();
		this.rdatereg = rdatereg;
		this.rterm = rterm;
		this.rstatus = rstatus;
		this.zname = zname;
		this.znumber = znumber;
		this.iname = iname;
		this.inumber = inumber;
		this.pname = pname;
		this.pmoney = pmoney;
		this.pminlose = pminlose;
		this.pmaxlose = pmaxlose;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public RegPolicy(int rid,int rstatus) {
		this.rid=rid;
		this.rstatus=rstatus;
	}
}
