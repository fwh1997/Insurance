package daomain;

public class Policy {
	private String pName;
	private Integer pMinYear;
	private Integer pMaxYear;
	private Integer tId;
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public Integer getpMinYear() {
		return pMinYear;
	}
	public void setpMinYear(Integer pMinYear) {
		this.pMinYear = pMinYear;
	}
	public Integer getpMaxYear() {
		return pMaxYear;
	}
	public void setpMaxYear(Integer pMaxYear) {
		this.pMaxYear = pMaxYear;
	}
	public Integer gettId() {
		return tId;
	}
	public void settId(Integer tId) {
		this.tId = tId;
	}
}
