package service;

import dao.UserDao;
import daomain.User;
import factory.BeanFactory;

public interface UserService{
	UserDao userDao=BeanFactory.getInstance("userdao", UserDao.class);
	int saveUser(User user);
}
