package service;

import java.util.List;

import dao.AdminDao;
import daomain.Admin;
import factory.BeanFactory;

public interface AdminService {
	AdminDao adminDao = BeanFactory.getInstance("admindao", AdminDao.class);
	List<Admin> findBestAdmin();
	int addAdmin(Admin admin);

}
