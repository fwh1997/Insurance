package service.impl;

import daomain.User;
import factory.BeanFactory;
import service.UserService;

public class UserServiceimpl implements UserService{
	

	@Override
	public int saveUser(User user) {
		// TODO Auto-generated method stub
		return userDao.saveUser(user);
	}	
}
