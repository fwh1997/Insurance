package service.impl;

import java.util.List;

import daomain.Admin;
import service.AdminService;

public class AdminServiceimpl implements AdminService{

	@Override
	public List<Admin> findBestAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminDao.addAdmin(admin);
	}

}
