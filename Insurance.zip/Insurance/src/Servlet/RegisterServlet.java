package Servlet;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;

import dao.UserDao;
import daomain.User;
import service.UserService;
import service.impl.UserServiceimpl;
@WebServlet("/RegisterServlet")
public class RegisterServlet extends BaseServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Test
	Object addUser(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
		request.setCharacterEncoding("utf-8");
		String name=request.getParameter("uName");
		String pwd=request.getParameter("uPwd");
		String email=request.getParameter("uEmail");
		System.out.println(name);
		System.out.println(pwd);
		System.out.println(email);
		User user=new User(name,pwd,email);
		Object uri=null;
		uri="/Test/login.jsp";
		return uri;
		
	}
	
	
	
}
