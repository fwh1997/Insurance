package Servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daomain.Admin;

@WebServlet("/adminService")
public class AdminService extends BaseServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Object addPartAdmin(HttpServletRequest request,HttpServletResponse response) { //
		String name = request.getParameter("aName");
		String pwd = request.getParameter("aPwd");
		Admin admin = new Admin(name, pwd, 1);
		adminService.addPartAdmin(request, response);//?????
		Object uri = null;
		//uri = request.getRequestDispatcher("/admin/index.jsp");
		uri = "/Test/login.jsp";
		return uri;
	}
}
